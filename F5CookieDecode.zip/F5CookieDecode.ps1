﻿param(
    $F5Cookie = $null
);

If ($F5Cookie) {
    #$F5Cookie = "277378826.20480.0000"

    $F5CookieSplit = $F5Cookie.split(".")

    If ($F5CookieSplit.Count -eq 3) {
        $F5cIP   = $F5CookieSplit[0];
        $F5cPort = $F5CookieSplit[1];
        $F5cNode = $F5CookieSplit[2];

<#
        $F5cIP
        $F5cPort
        $F5cNode
#>

        $F5IPa = (([uint32]"0x000000FF" -band ([uint32]$F5cIP))/([math]::Pow(2,0))).ToString();
        $F5IPb = (([uint32]"0x0000FF00" -band ([uint32]$F5cIP))/([math]::Pow(2,8))).ToString();
        $F5IPc = (([uint32]"0x00FF0000" -band ([uint32]$F5cIP))/([math]::Pow(2,16))).ToString();
        $F5IPd = (([uint32]"0xFF000000" -band ([uint32]$F5cIP))/([math]::Pow(2,24))).ToString();
        $F5IPAddr = "$F5IPa.$F5IPb.$F5IPc.$F5IPd";

        $F5PortLow  = (([uint32]"0x000000FF" -band ([uint32]$F5cPort))*([math]::Pow(2,8)));
        $F5PortHigh = (([uint32]"0x0000FF00" -band ([uint32]$F5cPort))/([math]::Pow(2,8)));
        $F5Port = ($F5PortHigh+$F5PortLow).ToString();

<#
        $F5PortLow.ToString();
        $F5PortHigh.ToString();
#>

        Write-Host "Node IP Address: $F5IPAddr  Port#: $F5Port"
    } else {
        Write-Host "Invalid formated parameter -F5Cookie of: $F5Cookie"
        Write-Host "Format should be in the form like the following: 277378826.20480.0000"
    }
} else {
    Write-Host "Missing parameter -F5Cookie"
    Write-Host "Format should be in the form like the following: 277378826.20480.0000"
}
