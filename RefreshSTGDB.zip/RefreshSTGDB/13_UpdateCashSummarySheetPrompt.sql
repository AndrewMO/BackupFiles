-- All workstation will show the prompt while login

update [WORKSTATIONS] set [CSS_PROMPT_TYPE] = 0 