update systeminfo set keywordvalue = 'Stage' 
where keyword = 'environment_identifier'