-- Search the day of the most transactions(Receipts) count in Year 2017
DECLARE @topDate DATETIME 
SELECT  top 1 @topDate = createDate FROM
(
SELECT 
  Convert(VARCHAR,[CreatedDate],23) as CreateDate,
  COUNT(1) AS  TransactionTotal 
FROM 
  [dbo].[FIN_Receipt]  WHERE
  [CreatedDate] BETWEEN '2017/01/01' AND  '2018/01/01' 
GROUP BY 
    Convert(VARCHAR,[CreatedDate],23)
)  subQuery
ORDER BY 
TransactionTotal  DESC 

SELECT @topDate as TopDate

--Search transaction total count on the day of the most transactions count in Year 2017
SELECT Count(*) total from [dbo].[FIN_Receipt] where [CreatedDate] between  @topDate and dateadd(ss,-1, dateadd(day,1,@topDate))

----Search all type transaction total
--  'purchase type' - enum.
--  -  Discount = 0
--  -  GeneralTransaction = 1
--  -  FacilityReservation = 2
--  -  ActivityRegistration = 3
--  -  Membership = 4
--  -  Adjustment = 5
--  -  PointOfSale = 6
--  -  MembershipRecurring = 7
--  -  ActivityRegistrationOnline = 8
--  -  FacilityReservationOnline = 9
--  -  MembershipOnline = 10
--  -  PaymentDelete = 11
--  -  GiftCard = 12
--  -  TeamRegistration = 13
--  -  TeamRegistrationOnline = 14
--  -  PlayerRegistration = 15
--  -  PlayerRegistrationOnline = 16
--  -  LeagueReservation = 19
--  -  ActivityReservation = 20
--  -  DayCampRegistration = 21
--  -  DayCampRegistrationOnline = 22
--  -  DayCampReservation = 23
--  -  LockerRental = 24
--  -  EquipmentRental = 25
--  -  LessonRegistration = 26
--  -  LessonRegistrationOnline = 27
--  -  LessonReservation = 28
--  -  LessonReservationOnline = 29
--  -  Golf = 30
--  -  GolfOnline = 31

SELECT PurchaseTypeID,Count(*) Total from fin_purchase where PurchaseID IN
(
  SELECT purchaseID FROM [dbo].[FIN_PaymentApplied] where receiptID IN  
  (select receiptID from [dbo].[FIN_Receipt] where [CreatedDate] between @topDate and dateadd(ss,-1, dateadd(day,1,@topDate)))
)
Group by PurchaseTypeID
