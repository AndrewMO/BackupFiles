//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("landing");
	truclient_step("1", "Navigate to 'https://tennislink.stag...in/Default.aspx'", "snapshot=Action_1.inf");
	lr_end_transaction("landing",0);
	lr_start_transaction("login");
	truclient_step("3", "Click on LOGIN JavaScript link", "snapshot=Action_3.inf");
	truclient_step("4", "Sign in", "snapshot=Action_4.inf");
	{
		truclient_step("4.1", "Click on Email textbox", "snapshot=Action_4.1.inf");
		truclient_step("4.2", "Type perftest02@mailinator.com in Email textbox", "snapshot=Action_4.2.inf");
		truclient_step("4.3", "Click on Email textbox", "snapshot=Action_4.3.inf");
		truclient_step("4.4", "Type inator.com in Email textbox", "snapshot=Action_4.4.inf");
		truclient_step("4.5", "Click on Password passwordbox", "snapshot=Action_4.5.inf");
		truclient_step("4.6", "Type ********** in Password passwordbox", "snapshot=Action_4.6.inf");
		truclient_step("4.7", "Click on Sign in button", "snapshot=Action_4.7.inf");
		lr_end_transaction("login",0);
	}
	lr_start_transaction("logout");
	truclient_step("6", "Click on LOGOUT JavaScript link", "snapshot=Action_6.inf");
	lr_end_transaction("logout",0);

	return 0;
}
